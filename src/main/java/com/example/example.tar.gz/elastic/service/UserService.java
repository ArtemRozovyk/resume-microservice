package com.example.elastic.service;

import com.example.elastic.domain.User;

/**
 * @author xyw
 * @date 2020/12/02
 */
public interface UserService {
    User findOne();
}
